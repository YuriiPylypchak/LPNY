$(document).ready(function () {
    $('.burgerBtn').click(function (event) {
        $('.burgerMenu').toggleClass('active');
    });
});
